python-adventure-game
==============
.. image:: https://travis-ci.org/allanburleson/python-adventure-game.svg?branch=master

This is a text-based adventure game engine written in Python. There are better ones out there; I'm just making this for fun.

See example.py for an example game with the engine and demo.py for a more complicated game.  

Python 3.6 is required because I'm the only user so it doesn't matter.

